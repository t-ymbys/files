##########
import time
start_test = time.time()
#####データ読み込み#####
import pandas as pd
##########設定##########
##オーダー数設定##
n = 1300
##納期調整##
D_min = 39     #最小値
D_max = 39     #最大値
#input, outputファイル名用ラベル：
#D[i] + alpha -> d
#d[i] = D_min + (D_max - D_min)*(D[i] - n_dead_min)/(n_dead_max - n_dead_min) -> nd
name = '46'
condition = 'd'
alpha = 0 #納期緩和用D[i]+alpha -> 基本は0にしておく
objective = 'max' #max, mean, lead_mean, surplus_mean
d_condition = 1 #1で納期制約あり、0で納期制約なし -> surplus_mean以外は1にしておく
setting_str = ['name', 'condition', 'alpha', 'objective', 'd_condition']
setting = [name, condition, alpha, objective, d_condition]
print('#####setting#####')
for i in range(len(setting_str)):
    print(setting_str[i] + '=' + str(setting[i]))
print('##########')
##########設定##########
#####input, outputパス#####
import os
input_path = './input/' + name + '.csv'
output_folder = './output/' + 'f_' + name + '_' + str(n) + '_' + condition + '_' + objective
os.makedirs(output_folder, exist_ok=True)
output_path =  output_folder + '/output_f_' + name + '_' + str(n) + '_' + condition + '_' + objective
#####データ読み込み#####
df = pd.read_csv(input_path)
df = df[df['order_id'] <= n ]
df.loc[df['child_id'] > n, 'child_id'] = 0
df_r = pd.read_csv('./input/' + name + '_r.csv')
#print('df', df)
#print('df_r', df_r)
#####高速化用#####
df_child = df.loc[df['child_id'] > 0]
order_list = df_child['order_id'].values.tolist()
task_list = df_child['task_id'].values.tolist()
child_list = df_child['child_id'].values.tolist()
#print(df_child)
#print(df_child['order_id'].values.tolist())
#print(df_child['task_id'].values.tolist())
#print(df_child['child_id'].values.tolist())
#####定数設定#####
import numpy as np
#パラメータ
n_orders = df['order_id'].max()                         # オーダー数（N）
n_task_min = df['size'].min()                           # タスク数の最小値（min K_i）
n_task_max = df['size'].max()                           # タスク数の最大値（max K_i）
n_child = df[df['child_id'] > 0]['child_id'].count()    #合流タスク数(num of L_i)
n_dead_max = df['delivery_date'].max()                  #オーダーごとの納期の最大値（max D_i） 
n_dead_min = df['delivery_date'].min()                  # オーダーごとの納期の最小値（min D_i）
n_resources = df['wc_id'].max()                         # リソース数(M)
# 作業日数（=n_dead_max）
if condition == 'd':
    n_days = df['delivery_date'].max() + alpha
elif condition == 'nd':
    n_days = D_max             
#パラメータチェック
n_set_st = ['n_orders', 'n_task_min', 'n_task_max', 'n_child', 'n_dead_max', 'n_dead_min', 'n_resources', 'n_days']
n_set = [n_orders, n_task_min, n_task_max, n_child, n_dead_max, n_dead_min, n_resources, n_days]
print('#####parameter#####')
for i in range(len(n_set)):
    print(n_set_st[i] + '=' + str(n_set[i]))
print('##########')
#タスク数K_i, 納期D_i: 
df_sd = df[['order_id', 'size', 'delivery_date']].drop_duplicates().reset_index()
#print(df_sd)
K = []
D = []
for i in range(n_orders):
    K.append(df_sd['size'][i])
    D.append(df_sd['delivery_date'][i])
#print('K',K)
#print('D',D)
#t_ikの作業時間c_ij, 機械割り当てr_ij, R_ija, 親子関係p_iki':
c = np.zeros((n_orders, n_task_max))
r = np.zeros((n_orders, n_task_max)) 
p = np.zeros((n_orders, n_task_max, n_orders))       #親子間オーダー（t_ikに合流するオーダーo_i'を指定する）
#q = np.zeros((n_orders, n_task_max, n_orders))       #親子間オーダー（t_ikに合流するオーダー
C = {}  # オーダー×タスクごとの作業時間（dictionary）
C = np.zeros((n_orders, n_task_max, n_resources))    # オーダー×タスクの作業時間（初期化）
R = {}  # オーダー×タスクごとのリソース（dictionary）
l = 0
for i in range(n_orders):
    for k in range(K[i]):
        c[i][k] = df[(df['order_id']==i+1)&(df['task_id']==k+1)]['working_time'][l]
        r[i][k] = df[(df['order_id']==i+1)&(df['task_id']==k+1)]['wc_id'][l] - 1
        #for j in range(n_orders):
        #    if df[(df['order_id']==i+1)&(df['task_id']==k+1)]['child_id'][l] == j + 1:
        #        p[i][k][j] = 1
        #    else:
        #        p[i][k][j] = 0
        C[i, k, int(r[i][k])] = c[i][k]
        key = str(i) + '_' + str(k)
        R[key] = int(r[i][k])
        l += 1

#for i in range(len(order_list)):
    #q[order_list[i]-1][task_list[i]-1][child_list[i]-1] = 1
#    p[order_list[i]-1][task_list[i]-1][child_list[i]-1] = 1
#print(len(order_list))
#print(np.nonzero(np.array(p)-np.array(q)))

#print('c = ', c) #-> df_c
#print('r = ', r) #-> df_resources
#print('p = ', p) 
#print('C', C)
#print('R', R)
#1日あたりの機械使用上限：
C_max = []  #C_a
for a in range(n_resources):
    C_max.append(df_r['upper_bound'][a])
#print(C_max)
#日程:
w = list(range(n_days))
#print(w)

print('end set parameter')
t = time.time() - start_test
#処理時間
print ("Time:{0}".format(t) + "[sec]")

#####オーダー/タスクごとの機械と作業時間#####
#clumns_task = ['task_' + str(k+1) for k in range(n_task_max)]
#df_resources = pd.DataFrame(columns=clumns_task)
#df_c = pd.DataFrame(columns=clumns_task)
#for i in range(n_orders):
#    tmp1 = pd.Series([C[i, k, R[str(i) + '_' + str(k)]] if k < K[i] else 0 for k in range(n_task_max)],
#                       index=clumns_task, name='od_' + str(i+1))
#    tmp2 = pd.Series([str(int(R[str(i) + '_' + str(k)])) if k < K[i] else 'NA' for k in range(n_task_max)],
#                       index=clumns_task, name='od_' + str(i+1))
#    df_c = df_c.append(tmp1)  # 作業時間の割り当て
#    df_resources = df_resources.append(tmp2)  # リソース番号の割り当て
#print('df_c', df_c)
#print('df_resources', df_resources)

#####PuLPによる求解#####
import pulp
#from gurobipy import * 
from pulp import GUROBI_CMD
## 最適化問題の設定
prob = pulp.LpProblem('scheduling', pulp.LpMinimize)
## 最適化する変数の設定
# バイナリ変数 X_{iks}
X = pulp.LpVariable.dicts('X', (range(n_orders), range(n_task_max), range(n_days)), cat='Binary')
if objective == 'max':
    # 最長工期 W_max
    W_max = pulp.LpVariable('W_max', lowBound=0)
elif objective == 'mean':
    # 終了日の平均 W_mean
    W_mean = pulp.LpVariable('W_mean', lowBound=0)
elif objective == 'lead_mean':
    # リードタイム平均 W_lead_mean
    W_lead_mean = pulp.LpVariable('W_lead_mean', lowBound=0)
elif objective == 'surplus_mean':
    # 余剰時間の平均 W_surplus_mean
    W_surplus_mean = pulp.LpVariable('W_surplus_mean')
## 制約条件の設定
# タスクの完備性
for i in range(n_orders):
    for k in range(K[i]):
        prob += pulp.lpSum(X[i][k][s] for s in range(n_days)) == 1
# オーダーのタスク順序制約
for i in range(n_orders):
    for k in range(K[i] - 1):
        prob += pulp.lpSum((X[i][k+1][s] - X[i][k][s]) * w[s] for s in range(n_days)) >= 1
# オーダーの納期制約
d = []
for i in range(n_orders):
    if condition == 'd':
        d.append(D[i]+alpha)
    elif condition == 'nd':
        d.append( D_min + ( (D_max - D_min) * ( ( D[i] - n_dead_min ) / ( n_dead_max - n_dead_min ) ) ) )
    if d_condition == 1:
        prob += pulp.lpSum(X[i][K[i]-1][s] * w[s] for s in range(n_days)) <= int(d[i])
        #print('d=1')
    #else:
        #print('d=0')
# 機械の稼働時間制約
for a in range(n_resources):
    for s in range(n_days):
        prob += pulp.lpSum( C[i, k, a] * X[i][k][s] for i in range(n_orders) for k in range(K[i])) <= C_max[a] 
#####
## オーダー親子間順序制約
#for i in range(n_orders):
#    for k in range(K[i]):
#        for j in range(n_orders):
#            prob += pulp.lpSum((X[i][k][s] - X[j][K[j]-1][s]) * w[s] * p[i][k][j] for s in range(n_days)) >= p[i][k][j]
for i in range(len(order_list)):
    prob += pulp.lpSum((X[order_list[i]-1][task_list[i]-1][s] - X[child_list[i]-1][K[child_list[i]-1]-1][s]) * w[s] for s in range(n_days)) >= 1
#####
## 隣接タスク作業日間隔上限（10は適当な値）
for i in range(n_orders):
    for k in range(K[i] - 1):
        prob += pulp.lpSum((X[i][k+1][s] - X[i][k][s]) * w[s] for s in range(n_days)) <= 10
#####
## 目的関数の設定
if objective == 'max':
    # 最大工期の不等式制約による定義
    for i in range(n_orders):
        prob += pulp.lpSum(X[i][K[i]- 1][s] * w[s] for s in range(n_days)) <= W_max
    # 最大工期を目的関数に設定
    prob += W_max
elif objective == 'mean':
    prob += pulp.lpSum(pulp.lpSum(X[i][K[i]-1][s] * w[s] / n_orders  for s in range(n_days)) for i in range(n_orders)) == W_mean
    prob += W_mean
elif objective == 'lead_mean':
    prob += pulp.lpSum(pulp.lpSum((X[i][K[i]-1][s] - X[i][0][s] )* w[s] / n_orders  for s in range(n_days)) for i in range(n_orders)) == W_lead_mean
    prob += W_lead_mean
elif objective == 'surplus_mean':
    prob += pulp.lpSum(pulp.lpSum((X[i][K[i]-1][s] * w[s] - d[i] ) / n_orders  for s in range(n_days)) for i in range(n_orders)) == W_surplus_mean
    prob += W_surplus_mean
## 求解の実行
#####実行時間の測定#####
import time
start = time.time()
#print(pulp.LpStatus[prob.solve()])
print(pulp.LpStatus[prob.solve(GUROBI_CMD())]) #Gurobi用
#try:
#     print(pulp.LpStatus[prob.solve(GUROBI_CMD())]) #Gurobi用
#except Exception:
#     logger.debug('Problem infeasible')
t = time.time() - start
if objective == 'max':
    #最大工数i
    print('Obj : W_max = ', W_max.value() + 1)
elif objective == 'mean':
    #平均終了時間
    print('Obj : W_mean = ', W_mean.value() +1)
elif objective == 'lead_mean':
    #平均終了時間
    print('Obj : W_lead_mean = ', W_lead_mean.value() +1)
elif objective == 'surplus_mean':
    #平均終了時間
    print('Obj : W_surplus_mean = ', W_surplus_mean.value() +1)
#処理時間
print ("Time_GUROBI:{0}".format(t) + "[sec]")

print('end solve')
t = time.time() - start_test
#処理時間
print ("Time:{0}".format(t) + "[sec]")

#####最適解のテーブル出力（オーダー、タスク、実施日）#####
out_df = pd.DataFrame(columns=['order_id', 'task_id', 'wc_id', 'day']) #最適解出力用
out_dic = {} #機械r_a 実施日w_s の組からタスクt_ikを出力する辞書a_s -> i_k
key_list = [] #out_dicキー
count=0
for i in range(n_orders): #オーダー
    for k in range(K[i]): #タスク
        for s in range(n_days): #実施日
            if X[i][k][s].value() == 1: #日程が存在しているとき以下を実行
                tmp_se = pd.Series([i+1, k+1, 1+np.argmax(C[i,k,:]), s+1], index=out_df.columns, name=str(count)) #t_ik, C[i,k,:]の最大を取るインデックス -> ノンゼロのインデックスa, sをメモ
                out_df = out_df.append(tmp_se) #メモした値をout_dfに
                key = str(1+np.argmax(C[i,k,:])) + '_' + str(s+1) #t_ikの機械a、実施日sをkey（a_s）
                value = str(i+1) + '_' + str(k+1) #値をi_k
                if key in key_list: #a_sのかぶりがあったらカンマをつけて', i_k'を追加　a_s -> i_k, i'_k',,,,
                    out_dic[key] += ', ' + value 
                else: #a_sのかぶりがなかったら'i_k'を追加
                    out_dic[key] = value 
                    key_list.append(key)
                count += 1
out_df.to_csv(output_path + '_solution.csv') #出力
print('out_df', out_df)

w_max = out_df['day'].max()
w_mean = out_df.groupby('order_id').max()['day'].mean()
print('W_max = ', w_max)
print('W_mean = ', w_mean)

# 最適解によるスケジュール表（作業日ごとの機会の割り当て）
import math
#w_max = int(W_max.value() + 1) #最大工期　-> スケジュール表の最終日
schedule_columns = list(np.array(['w_' + str(i+1) for i in range(w_max)])) #スケジュール表のフィールド
capacity_columns = list(np.hstack([np.array(['w_' + str(i+1) for i in range(w_max)]), 'C_max'])) #hstackで配列の列結合（スケジュール日程+C_maxの表を
schedule_tbl = np.array(['w_' + str(i+1) for i in range(w_max)])
capacity_tbl = np.hstack([np.array(['w_' + str(i+1) for i in range(w_max)]), 'C_max'])
for a in range(n_resources): #機械ごと
    temp_list1 = []
    temp_list2 = []
    for s in range(w_max): #日程ごと
        key = str(a+1) + '_' + str(s+1)
        amnt = 0
        if key in out_dic.keys(): #keyが登録されていたら、index_listに', 'ごとに分割し、index i_kを登録
            temp = out_dic[key]
            index_list = temp.split(', ')
            for i in range(len(index_list)): #i_kごと
                sub_list = index_list[i].split('_') #i, kを分割
                sub1 = int(sub_list[0]) - 1 # i
                sub2 = int(sub_list[1]) - 1 # k
                amnt += C[sub1,sub2,a] # i, k, aの合計（r_aの実施日w_sの合計値C_asを算出）
        else: #登録されていなかったら空っぽ
            temp = '' 
        temp_list1.append(temp) # indexを追加
        temp_list2.append(amnt) # i, k, aを追加
    temp_list2.append(C_max[a]) #C_maxを追加
    temp_list1 = np.array(temp_list1) #np.arrayに変換
    schedule_tbl = np.vstack([schedule_tbl, temp_list1]) #vstackで配列の行結合
    capacity_tbl = np.vstack([capacity_tbl, temp_list2])
schedule_tbl = np.delete(schedule_tbl, 0, 0)
capacity_tbl = np.delete(capacity_tbl, 0, 0)
#index名, フィールド名
header1 = schedule_columns
header2 = capacity_columns
resource_name = ['r_' + str(a+1) for a in range(n_resources)] 
#listからDataFrame型へ
schedule_df = pd.DataFrame(schedule_tbl, columns=header1, index=resource_name)
capacity_df = pd.DataFrame(capacity_tbl, columns=header2, index=resource_name)
#print('schedule_df',schedule_df)
#print('capacity_df',capacity_df)
schedule_df.to_csv(output_path + '_schedule.csv') #出力
capacity_df.to_csv(output_path + '_capacity.csv') #出力

print('end output')
t = time.time() - start_test
#処理時間
print ("Time:{0}".format(t) + "[sec]")

#####制約条件の計算#####
import pandas as pd
import matplotlib.pyplot as plt
from pylab import rcParams
# タスクの完備性
calc_list1 = []
for i in range(n_orders):
    for k in range(K[i]):
        tmp = 0
        for s in range(n_days):
            tmp += X[i][k][s].value()
        calc_list1.append(int(tmp))
# オーダーのタスク順序制約
calc_list2 = []
for i in range(n_orders):
    tmp = 0
    for k in range(K[i] - 1):
        for s in range(n_days):
            tmp += (X[i][k+1][s].value() - X[i][k][s].value()) * w[s]
        tmp -= 1
    calc_list2.append(int(tmp))
# オーダーの納期制約
calc_list3 = []
for i in range(n_orders):
    tmp =0
    for s in range(n_days):
        tmp += X[i][K[i]-1][s].value() * w[s]
    calc_list3.append(int(d[i] - tmp))
# 機械の稼働時間制約
calc_list4 = []
for a in range(n_resources):
    for s in range(n_days):
        tmp = 0
        for i in range(n_orders):
            for k in range(K[i]):
                tmp += C[i,k,a] * X[i][k][s].value()
        if tmp > 0:
            calc_list4.append(int(C_max[a] - tmp))
# オーダー親子間順序制約
calc_list5 = []
#for i in range(n_orders):
#    for k in range(K[i]):
#      for j in range(n_orders):
#        tmp = 0
#        for s in range(n_days):
#          tmp += (X[i][k][s].value() - X[j][K[j]-1][s].value()) * w[s] * p[i][k][j]
#        if p[i][k][j] > 0:
#          calc_list5.append(int(tmp - p[i][k][j]))
for i in range(len(order_list)):
    tmp = 0
    for s in range(n_days):
        tmp += (X[order_list[i]-1][task_list[i]-1][s].value() - X[child_list[i]-1][K[child_list[i]-1]-1][s].value()) * w[s]
    calc_list5.append(int(tmp - p[order_list[i]-1][task_list[i]-1][child_list[i]-1]))
titles = ['completeness of tasks', 'ordering of tasks', 'time to delivery', 'resource capacity', 'ordering of parent']
xlabels = ['number of days', 'interval between tasks', 'number of days', 'margin capacity', 'interval between tasks']
ylabels = ['number of tasks', 'number of orders', 'number of orders', 'cumulative number of resources', 'number of orders']
lists = [calc_list1, calc_list2, calc_list3, calc_list4, calc_list5]
fig = plt.figure(figsize=(12,3))
for i in range(len(lists)):
  ax1 = fig.add_subplot(1,5,i+1)
  ax1.grid(True, which='major')
  ax1.hist(lists[i], bins=10, alpha=0.5, histtype='stepfilled', color='b')
  ax1.set_title(titles[i])
  ax1.set_ylabel(ylabels[i])
  ax1.set_xlabel(xlabels[i])
plt.tight_layout() 

print('end check')
t = time.time() - start_test
#処理時間
print ("Time_total:{0}".format(t) + "[sec]")
#plt.show()
fig.savefig(output_path + '_graph.png')
